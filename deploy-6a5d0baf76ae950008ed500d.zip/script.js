/* -------------------------------------------------------------
 * Sunaina Enterprises Custom Interactive Scripts
 * Since 2026
 * ------------------------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
  initHeaderScroll();
  initMobileNav();
  initScrollSpy();
  initAjaxForms();
});

/**
 * 1. Header Scroll Effect
 * Toggles dark blurred background state when scrolled.
 */
function initHeaderScroll() {
  const header = document.querySelector('.main-header');
  if (!header) return;

  const handleScroll = () => {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  };

  // Run on load and scroll
  handleScroll();
  window.addEventListener('scroll', handleScroll, { passive: true });
}

/**
 * 2. Mobile Navigation Drawer
 * Handles toggle actions for the mobile responsive menu.
 */
function initMobileNav() {
  const toggleBtn = document.querySelector('.mobile-nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  const navLinks = document.querySelectorAll('.nav-link');

  if (!toggleBtn || !navMenu) return;

  const toggleMenu = (open) => {
    const isExpanded = open !== undefined ? open : toggleBtn.getAttribute('aria-expanded') === 'true';
    toggleBtn.setAttribute('aria-expanded', !isExpanded);
    if (!isExpanded) {
      navMenu.classList.add('open');
      document.body.style.overflow = 'hidden'; // Lock background scroll when open
    } else {
      navMenu.classList.remove('open');
      document.body.style.overflow = '';
    }
  };

  toggleBtn.addEventListener('click', () => toggleMenu());

  // Close menu when a navigation link is clicked
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      toggleMenu(true); // Force close
    });
  });

  // Handle window resizing to reset body scroll lock if drawer was open
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
      navMenu.classList.remove('open');
      document.body.style.overflow = '';
      toggleBtn.setAttribute('aria-expanded', 'false');
    }
  });
}

/**
 * 3. Active Link Highlight (Scroll Spy)
 * Observes page scroll offsets and marks header link active based on current section viewport.
 */
function initScrollSpy() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  if (sections.length === 0 || navLinks.length === 0) return;

  const spyOptions = {
    root: null,
    rootMargin: '-20% 0px -60% 0px', // Strict center focus
    threshold: 0
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          }
        });
      }
    });
  }, spyOptions);

  sections.forEach(section => observer.observe(section));

  // Default Home active state if at very top
  window.addEventListener('scroll', () => {
    if (window.scrollY < 100) {
      navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#') {
          link.classList.add('active');
        }
      });
    }
  }, { passive: true });
}

/**
 * 4. Netlify Forms AJAX Submissions
 * Captures submit event, fires asynchronous POST request to Netlify, and provides premium feedback transitions.
 */
function initAjaxForms() {
  const retailerForm = document.getElementById('retailer-application-form');
  const contactForm = document.getElementById('general-contact-form');
  const enquiryForm = document.getElementById('enquiry-form');

  if (retailerForm) {
    retailerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleFormSubmit(retailerForm, 'retailer-form-wrapper', 'retailer-submit-btn', 'Retailer Application');
    });
  }

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleFormSubmit(contactForm, 'contact-form-wrapper', 'contact-submit-btn', 'General Inquiry');
    });
  }

  if (enquiryForm) {
    enquiryForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleFormSubmit(enquiryForm, 'enquiry-form-wrapper', 'enquiry-submit-btn', 'Business Enquiry');
    });
  }
}

/**
 * Common submit helper function.
 * Handles the async state, button animations, and success card swap.
 */
async function handleFormSubmit(form, wrapperId, submitBtnId, formType) {
  const wrapper = document.getElementById(wrapperId);
  const submitBtn = document.getElementById(submitBtnId);
  if (!wrapper || !form || !submitBtn) return;

  // Validate form details
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }

  // Set visual submitting states
  const originalBtnHTML = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = `<span>Sending...</span> <i class="fa-solid fa-spinner fa-spin"></i>`;
  submitBtn.style.opacity = '0.75';

  const formData = new FormData(form);

  try {
    const response = await fetch('/index.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(formData).toString()
    });

    if (response.ok) {
      // Smooth fade transition of form card
      wrapper.style.opacity = '0';
      wrapper.style.transform = 'translateY(-20px)';

      setTimeout(() => {
        // Swap with high-end Thank You state
        wrapper.innerHTML = `
          <div class="form-success-card">
            <div class="success-icon-wrapper">
              <i class="fa-solid fa-circle-check"></i>
            </div>
            <h3>Thank You!</h3>
            <p>Your ${formType} has been successfully submitted to Sunaina Enterprises.</p>
            <p style="margin-top: 15px; font-size: 0.85rem; color: var(--text-light);">
              Our wholesale management team is reviewing your details and will call or message you shortly.
            </p>
          </div>
        `;
        wrapper.style.opacity = '1';
        wrapper.style.transform = 'translateY(0)';
      }, 400);

    } else {
      throw new Error('Network response not OK');
    }
  } catch (error) {
    console.error('Submission failed:', error);
    
    // Fallback to error alert or reset button
    alert('Something went wrong during submission. Please check your internet connection and try again, or connect directly via WhatsApp.');
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalBtnHTML;
    submitBtn.style.opacity = '';
  }
}
