# Sunaina Enterprises

A premium, fast, and fully responsive landing page for **Sunaina Enterprises**—a trusted multi-product trading company based in Danapur, Patna, Bihar. Established in 2026, the company operates in wholesale bulk supplies, regional distribution, and direct retail channels.

This site is optimized for conversion, enabling business partners and retail outlets to quickly call, chat on WhatsApp, or apply to become a retailer directly via serverless web forms.

## 🚀 Key Features

- **Brand-first Vector Logo (`logo.svg`)**: Beautiful, high-resolution SVG monogram and typography that fits perfectly in both light and dark headers.
- **Premium User Experience**: Handcrafted custom CSS with glassmorphism visual accents, high-end hover responses, scroll-driven header blurring, and smooth layout entry transitions.
- **Interactive Forms (Netlify Forms)**:
  - **Retailer Application Form**: Captures owner name, shop name, contact number, location, and business category. Includes spam prevention with a silent honeypot (`bot-field`).
  - **General Message Form**: Enables standard wholesale catalog and collaboration inquiries.
- **Smooth AJAX Submission**: Forms submit without full-page reloads, transitioning into beautifully composed thank-you screens with real-time feedback.
- **Scroll Spy Active Navigation**: Automatically highlights active menu links as the user scrolls through sections.
- **No-Iframe Map Visualization fallback**: Utilizes a highly styled CSS radar visual pattern showing Danapur, Patna location, maintaining speed and aesthetic depth.

## 🛠️ Built With

- **HTML5 & Vanilla CSS3**: Uses clean semantic layouts, flexbox, CSS grid, and CSS custom properties (variables) for consistent theme design.
- **Vanilla JavaScript (ES6)**: Zero external weight. Light, fast, and robust DOM operations.
- **Netlify Forms**: Serverless backend integration for contact form submissions.
- **FontAwesome Free Icon Kit**: Delivers crisp and modern vector glyphs.
- **Google Fonts (Poppins)**: Elegant geometric sans-serif that fits a premium trading & distribution image.

## 💻 Running Locally

Since this is a high-performance static website, you can run it directly:

1. Double-click `index.html` to open it in any web browser.
2. Alternatively, serve it via Python's built-in server:
   ```bash
   python -m http.server 8000
   ```
   and navigate to `http://localhost:8000` in your browser.
3. For local emulation of Netlify Form submissions, use the Netlify CLI:
   ```bash
   netlify dev
   ```

## 📂 Project Structure

```text
├── index.html        # Entry point with semantic sections and forms
├── style.css         # Custom layout, responsive grids, interactive animations
├── script.js        # Scroll triggers, navigation drawer, AJAX submissions
├── logo.svg          # Beautiful custom brand identifier
└── README.md         # General project instructions
```
